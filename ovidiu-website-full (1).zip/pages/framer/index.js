export default function Framer() {
  return <div className="p-8 text-white">Framer Website Services - Stunning visuals, high performance</div>;
}
