export default function SEO() {
  return <div className="p-8 text-white">SEO Services Page - Optimized for Search Engines</div>;
}
