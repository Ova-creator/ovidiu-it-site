export default function Automation() {
  return <div className="p-8 text-white">Automation Services Page - Smart automations that save time</div>;
}
